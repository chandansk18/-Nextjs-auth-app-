'use client';

import { useState } from 'react';
import Link from 'next/link';

import {
  FaUsers,
  FaBook,
  FaClipboardList,
  FaChevronDown,
  FaChevronUp,
  FaChevronLeft,
  FaChevronRight,
} from 'react-icons/fa';

export default function Sidebar({ isSidebarOpen, onToggleSidebar }) {
  const [openMenu, setOpenMenu] = useState({
    courses: true,
    tests: true,
    books: true,
    users: true,
  });

  const toggleMenu = (menu) => {
    setOpenMenu((prev) => ({ ...prev, [menu]: !prev[menu] }));
  };

  return (
    <>
      {/* Toggle button - always visible */}
      <button
        onClick={onToggleSidebar}
        className="fixed top-4 left-4 z-50 p-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 shadow transition-transform duration-300"
        title={isSidebarOpen ? 'Collapse Sidebar' : 'Expand Sidebar'}
      >
        {isSidebarOpen ? <FaChevronLeft /> : <FaChevronRight />}
      </button>

      {/* Sidebar */}
      <aside
        className={`bg-white shadow-md p-4 pt-16 transition-all duration-300 h-screen fixed top-0 left-0 z-40 ${
          isSidebarOpen ? 'w-64' : 'w-0 overflow-hidden'
        }`}
      >
        <div className={`${isSidebarOpen ? 'block' : 'hidden'}`}>
          <h2 className="text-xl font-semibold mb-6">Lms Admin Panel</h2>

          <ul className="space-y-2 pb-24">
            <Link href="/dashboard">
              <li className="bg-purple-600 text-white px-3 py-2 rounded font-semibold cursor-pointer">
                Dashboard
              </li>
            </Link>

            {/* Courses */}
            <li className="cursor-pointer" onClick={() => toggleMenu('courses')}>
              <div className="flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">
                <span className="flex items-center gap-2">
                  <FaClipboardList /> Courses Management
                </span>
                {openMenu.courses ? <FaChevronUp /> : <FaChevronDown />}
              </div>
              {openMenu.courses && (
                <ul className="ml-6 mt-1 text-sm text-gray-700 space-y-1">
                  <li className="hover:text-purple-600 cursor-pointer">Add Course</li>
                  <li className="hover:text-purple-600 cursor-pointer">Course List</li>
                </ul>
              )}
            </li>

            {/* Tests */}
            <li className="cursor-pointer" onClick={() => toggleMenu('tests')}>
              <div className="flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">
                <span className="flex items-center gap-2">
                  <FaClipboardList /> Test Management
                </span>
                {openMenu.tests ? <FaChevronUp /> : <FaChevronDown />}
              </div>
              {openMenu.tests && (
                <ul className="ml-6 mt-1 text-sm text-gray-700 space-y-1">
                  <li className="hover:text-purple-600 cursor-pointer">Add Test</li>
                  <li className="hover:text-purple-600 cursor-pointer">Test List</li>
                </ul>
              )}
            </li>

            {/* Books */}
            <li className="cursor-pointer" onClick={() => toggleMenu('books')}>
              <div className="flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">
                <span className="flex items-center gap-2">
                  <FaBook /> Book Management
                </span>
                {openMenu.books ? <FaChevronUp /> : <FaChevronDown />}
              </div>
              {openMenu.books && (
                <ul className="ml-6 mt-1 text-sm text-gray-700 space-y-1">
                  <li className="hover:text-purple-600 cursor-pointer">Add Book</li>
                  <li className="hover:text-purple-600 cursor-pointer">Book List</li>
                </ul>
              )}
            </li>

            {/* Users */}
            <li className="cursor-pointer" onClick={() => toggleMenu('users')}>
              <div className="flex justify-between items-center px-3 py-2 hover:bg-gray-100 rounded">
                <span className="flex items-center gap-2">
                  <FaUsers /> Users Management
                </span>
                {openMenu.users ? <FaChevronUp /> : <FaChevronDown />}
              </div>
              {openMenu.users && (
                <ul className="ml-6 mt-1 text-sm text-gray-700 space-y-1">
                  <Link href="/user-list" className="hover:text-purple-600 cursor-pointer block">
                    User List
                  </Link>
                </ul>
              )}
            </li>
          </ul>

          {/* Logout */}
          <button
            onClick={() => (window.location.href = '/')}
            className="w-full absolute bottom-16 left-0 px-4 py-2 text-white bg-red-500 hover:bg-red-600 rounded"
          >
            Logout
          </button>
        </div>
      </aside>
    </>
  );
}
