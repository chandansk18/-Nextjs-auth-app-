'use client';

const UserTableHeading = ({ title, count }) => {
  return (
    <div className="mb-4 flex justify-between items-center bg-purple-100 p-4 rounded-lg">
      <h2 className="text-xl font-bold text-purple-800">
        {title} {count !== undefined && <span className="text-gray-600 text-sm">({count} entries)</span>}
      </h2>
    </div>
  );
};

export default UserTableHeading;


