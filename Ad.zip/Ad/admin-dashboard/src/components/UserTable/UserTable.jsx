'use client';

import { useState } from 'react';
import { Table, Input, Tag, Button } from 'antd';
import { useRouter } from 'next/navigation';
import {
  SearchOutlined,
  EyeOutlined,
  CheckCircleTwoTone,
  CloseCircleTwoTone,
} from '@ant-design/icons';
import { users as initialData } from '@/data/maindata'; // ✅ Import your users data

const UserTable = () => {
  const [searchText, setSearchText] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [data, setData] = useState(initialData);
  const router = useRouter();

  const handleSearch = (e) => {
    setSearchText(e.target.value);
    setCurrentPage(1);
  };

  const handleAction = (id, action) => {
    setData((prevData) =>
      prevData.map((user) =>
        user.id === id && !user.status
          ? { ...user, status: action === 'accept' ? 'Active' : 'Rejected' }
          : user
      )
    );
  };

  const filteredData = data.filter((user) =>
    user.name.toLowerCase().includes(searchText.toLowerCase())
  );

  const columns = [
    {
      title: 'User Id',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: 'Full Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      key: 'phone',
      render: (text) => (
        <>
          {text}{' '}
          {text.length === 10 ? (
            <CheckCircleTwoTone twoToneColor="#52c41a" />
          ) : (
            <CloseCircleTwoTone twoToneColor="#ff4d4f" />
          )}
        </>
      ),
    },
    {
      title: 'Gender',
      dataIndex: 'gender',
      key: 'gender',
    },
    {
      title: 'Status',
      key: 'status',
      width: 180,
      render: (_, record) =>
        !record.status ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <Button
              type="primary"
              size="small"
              onClick={() => handleAction(record.id, 'accept')}
            >
              Accept
            </Button>
            <Button
              danger
              size="small"
              onClick={() => handleAction(record.id, 'decline')}
            >
              Decline
            </Button>
          </div>
        ) : (
          <Tag color={record.status === 'Active' ? 'green' : 'red'}>
            {record.status}
          </Tag>
        ),
    },
    {
      title: 'View',
      key: 'view',
      render: (_, record) => (
        <EyeOutlined
          style={{ color: '#722ed1', cursor: 'pointer' }}
          onClick={() => router.push(`/user-list/${record.id}`)}
        />
      ),
    },
  ];

  return (
    <div className="p-6 w-full">
      <div className="mb-4">
        <Input
          placeholder="Search by name"
          prefix={<SearchOutlined />}
          value={searchText}
          onChange={handleSearch}
          style={{ width: 300 }}
        />
      </div>

      <div style={{ overflowX: 'auto' }}>
        <Table
          dataSource={filteredData.map((user) => ({ ...user, key: user.id }))}
          columns={columns}
          pagination={{
            current: currentPage,
            pageSize: 10,
            onChange: (page) => setCurrentPage(page),
          }}
          scroll={{ x: 'max-content' }}
        />
      </div>
    </div>
  );
};

export default UserTable;
