'use client';
import Link from 'next/link'; // Add this at the top


import { useState } from 'react';
import {
  FaUsers,
  FaMoneyBill,
  FaBook,
  FaClipboardList,
  FaChevronDown,
  FaChevronUp,
  FaBars,
} from 'react-icons/fa';
import { MdLibraryBooks } from 'react-icons/md';

const stats = [
  { title: 'Total Users', value: '10', icon: <FaUsers />, color: 'bg-pink-500' },
  { title: 'Total Income (₹)', value: '₹16,998.00', icon: <FaMoneyBill />, color: 'bg-blue-500' },
  { title: 'Total Courses', value: '6', icon: <FaClipboardList />, color: 'bg-pink-500' },
  { title: 'Total Course Enrollments', value: '5', icon: <FaUsers />, color: 'bg-blue-500' },
  { title: 'Course Revenue (₹)', value: '₹7,998.00', icon: <FaMoneyBill />, color: 'bg-green-500' },
  { title: 'Total Tests', value: '3', icon: <FaClipboardList />, color: 'bg-pink-500' },
  { title: 'Test Enrollments', value: '3', icon: <FaUsers />, color: 'bg-blue-500' },
  { title: 'Test Revenue (₹)', value: '₹9,000.00', icon: <FaMoneyBill />, color: 'bg-green-500' },
  { title: 'Total Books', value: '10', icon: <MdLibraryBooks />, color: 'bg-pink-500' },
  { title: 'Total Orders', value: '0', icon: <FaUsers />, color: 'bg-blue-500' },
  { title: 'Book Revenue (₹)', value: '₹0.00', icon: <FaMoneyBill />, color: 'bg-green-500' },
];

export default function DashboardPage() {
  const [openMenu, setOpenMenu] = useState({
    courses: true,
    tests: true,
    books: true,
    users: true,
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleMenu = (menu) => {
    setOpenMenu((prev) => ({ ...prev, [menu]: !prev[menu] }));
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      

      {/* Main Content */}
      <main className="flex-1 p-6">


        <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
        <p className="text-gray-600 mb-6">Welcome to the dashboard</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {stats.map((stat, idx) => (
            <div
              key={idx}
              className="bg-white rounded-lg p-4 shadow-md flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className={`p-3 text-white rounded-full ${stat.color}`}>
                  {stat.icon}
                </div>
                <div>
                  <p className="text-gray-600 text-sm">{stat.title}</p>
                  <p className="text-lg font-bold">{stat.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
