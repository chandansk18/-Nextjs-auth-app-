// redux/authSlice.js

import Cookies from "js-cookie";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "../../lib/axios";

const initialState = {
  isLoggedIn: false,
  user: null,
  status: "idle",
  error: null,
};

// Async thunk for verifying the token
export const verifyToken = createAsyncThunk("auth/verifyToken", async () => {
  const token = Cookies.get(process.env.NEXT_PUBLIC_WEB_TOKEN);
  if (!token) return;
  const response = await axios.get("/api/verify-token", {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
});

// Async thunk for refreshing the token
export const refreshToken = createAsyncThunk("auth/refreshToken", async () => {
  const refreshToken = Cookies.get(process.env.NEXT_PUBLIC_REFRESH_TOKEN);
  if (!refreshToken) return;
  const response = await axios.post("/api/refresh-token", { refreshToken });

  return response.data;
});

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
        loginSuccessWithoutRefresh: (state, action) => {
      state.isLoggedIn = true;
      state.user = action.payload.user;
      Cookies.set(
        process.env.NEXT_PUBLIC_WEB_TOKEN,
        action.payload?.accessToken
      );
    },
    loginSuccess: (state, action) => {
      state.isLoggedIn = true;
      state.user = action.payload.user;
      Cookies.set(
        process.env.NEXT_PUBLIC_WEB_TOKEN,
        action.payload?.accessToken
      );
      Cookies.set(
        process.env.NEXT_PUBLIC_REFRESH_TOKEN,
        action.payload?.refreshToken
      );
    },
    logout: (state) => {
      state.isLoggedIn = false;
      state.user = null;
      Cookies.remove(process.env.NEXT_PUBLIC_WEB_TOKEN);
      Cookies.remove(process.env.NEXT_PUBLIC_REFRESH_TOKEN);
      localStorage.clear();
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(verifyToken.fulfilled, (state, action) => {
        state.isLoggedIn = true;
        state.status = "fulfilled";
        state.user = action.payload.data;
        state.error = null;
      })
      .addCase(verifyToken.rejected, (state, action) => {
        state.isLoggedIn = false;
        state.status = "rejected";
        state.error = action.error.message;
      })
      .addCase(refreshToken.fulfilled, (state, action) => {
        Cookies.set(process.env.NEXT_PUBLIC_WEB_TOKEN, action.payload?.data);
      })
      .addCase(refreshToken.rejected, (state, action) => {
        state.error = action.error.message;
      });
  },
});

export default authSlice.reducer;
export const { loginSuccess, loginSuccessWithoutRefresh, logout } = authSlice.actions;
