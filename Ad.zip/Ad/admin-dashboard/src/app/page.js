'use client';

import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { TextField, FormControlLabel, Checkbox, Button } from '@mui/material';
import GoogleIcon from '@mui/icons-material/Google';
import { motion } from 'framer-motion';
import { getIdToken, signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../utils/firebase'; // adjust this path if needed
import axios from '../lib/axios'; // make sure this path matches where axios.js is placed
import { useDispatch } from 'react-redux';
import {loginSuccess,loginSuccessWithoutRefresh,} from '../redux/slices/authSlice';
 
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const router = useRouter();
  const dispatch = useDispatch();

//  const signIn = async () => {
  //   try {  
  //     const userCredential = await signInWithEmailAndPassword(auth, email, password);
  //     const token = await userCredential.user.getIdToken();

  //     const response = await axios.post("/api/login", {
  //       idToken: token,
  //       roleId: "ADMIN",
  //     });

  //     if (response?.data?.status === "success") {
  //       toast.success(response.data.message);
  //       if (rememberMe) {
  //         dispatch(loginSuccess(response.data.data));
  //       } else {
  //         dispatch(loginSuccessWithoutRefresh(response.data.data));
  //       }
  //       const userRole = response.data.data.user.roleId;
  //       router.push(userRole === "SUPER ADMIN" ? "/main" : "/main/dashboard");
  //     }
  //   } catch (error) {
  //     console.error("Login Error:", error);
  //     toast.error("Invalid credentials.");
  //   }
  // };

  // In your login handler (e.g., page.js or Login.jsx)



const handleLogin = async () => {
  // TEMPORARY MOCK DATA
  const mockUser = {
    name: 'Chandan',
    email: 'chandan@gmail.com',
    password: '123456',
    role: 'admin',
  };

  dispatch(loginSuccess({
    user: mockUser,
    accessToken: 'fake-web-token',
    refreshToken: 'fake-refresh-token',
  }));

  router.push('/dashboard'); // or wherever you redirect after login
};


  const handleGoogleSignIn = async () => {
    try {
      const response = await signInWithGoogle();
      const token = await getIdToken(response.user);

      await axios.post("/api/login", {
        idToken: token,
        roleId: "ADMIN",
      });

      toast.success('Google Sign-In successful');
      router.push('/dashboard');
    } catch (error) {
      toast.error(`Google Sign-In failed: ${error.message}`);
    }
  };

  return (
    <div className="relative h-screen w-screen">
      <img
        src="/login.webp"
        alt="Background"
        className="absolute inset-0 w-full h-full object-cover"
      />

      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <motion.form
          onSubmit={(e) => {
            e.preventDefault();
            handleLogin();
          }}
          className="w-96 md:w-[450px] space-y-5 border border-gray-300 p-8 rounded-lg shadow-lg"
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.7)',
            backdropFilter: 'blur(10px)',
          }}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <h1 className="text-3xl font-bold text-center">Sign In</h1>
          <p className="text-center text-gray-600">
            Welcome user, please sign in to continue
          </p>

          <TextField
            label="Email"
            variant="outlined"
            fullWidth
            margin="normal"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <TextField
            label="Password"
            type="password"
            variant="outlined"
            fullWidth
            margin="normal"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <FormControlLabel
            control={
              <Checkbox
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                color="primary"
              />
            }
            label="Remember Me"
          />

          <button
            type="submit"
            className="bg-blue-500 text-white p-3 w-full rounded-md hover:bg-blue-600 transition-colors"
          >
            Login
          </button>

          <div className="flex items-center my-4">
            <div className="flex-grow h-px bg-gray-300" />
            <span className="px-2 text-gray-500 text-sm">OR</span>
            <div className="flex-grow h-px bg-gray-300" />
          </div>

          <Button
            variant="outlined"
            fullWidth
            startIcon={<GoogleIcon />}
            onClick={handleGoogleSignIn}
            sx={{ mt: 2 }}
          >
            Sign in with Google
          </Button>
        </motion.form>
      </motion.div>
    </div>
  );
}
