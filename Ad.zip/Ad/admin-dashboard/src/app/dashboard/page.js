'use client';

import Dashboard from '@/components/Dashboard/Dashboard';
import Sidebar from '@/components/Sidebar';

export default function DashboardPage() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}
