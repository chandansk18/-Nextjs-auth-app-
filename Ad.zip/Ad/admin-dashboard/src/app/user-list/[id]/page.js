// app/user-list/[id]/page.jsx
'use client';

import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { users } from '@/data/maindata';
import UserTableHeading from '@/components/UserTable/UserTableHeading';
import { Card, Typography, Tag, Result } from 'antd';

const { Title, Text } = Typography;

export default function UserDetailPage() {
  const { id } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const found = users.find((u) => u.id.toString() === id);
    setUser(found);
  }, [id]);

  if (!user) {
    return (
      <Result
        status="404"
        title="User Not Found"
        subTitle="The requested user does not exist in the list."
      />
    );
  }

  const getStatusColor = (status) => {
    switch ((status ?? '').toLowerCase()) {
      case 'active':
        return 'green';
      case 'inactive':
        return 'red';
      case 'pending':
        return 'orange';
      default:
        return 'default';
    }
  };

  return (
    <div style={{ padding: '24px' }}>
      <UserTableHeading title="User Panel" />
      <Card
        variant="outlined"
        title={
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Title level={4} style={{ margin: 0 }}>User Details</Title>
            <Tag color={getStatusColor(user.status)}>
              {user.status ?? 'Not Available'}
            </Tag>
          </div>
        }
      >
        <p><Text strong>ID:</Text> {user.id}</p>
        <p><Text strong>Name:</Text> {user.name}</p>
        <p><Text strong>Email:</Text> {user.email}</p>
        <p><Text strong>Phone:</Text> {user.phone}</p>
        <p><Text strong>Gender:</Text> {user.gender}</p>
      </Card>
    </div>
  );
}
