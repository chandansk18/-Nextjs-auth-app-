import DashboardLayout from '@/app/dashboard/layout';

export default function Layout({ children }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}
