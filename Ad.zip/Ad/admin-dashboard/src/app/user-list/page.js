'use client';

import React from 'react';
import UserTable from '@/components/userTable/UserTable';
import { users as userData } from '@/data/maindata';
import UserTableHeading from '@/components/UserTable/UserTableHeading';

export default function UserListPage() {
  return (
    <div className="p-6 w-full">
      <UserTableHeading title= "User Panel"/>
      <UserTable data={userData} />
    </div>
  );
}
