import './globals.css';
import { AuthProvider } from '../contexts/AuthContext';
//import { ReduxProvider } from '../middleware/providers';  // ✅ Correct import
import { Toaster } from 'react-hot-toast';
//import {ReduxProvider} from '../redux/Reduxprovider';
import { ReduxProvider } from '../middleware/providers';


export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Toaster position="top-right" />
        <ReduxProvider>      {/* ✅ Fix here */}
          <AuthProvider>
            {children}
          </AuthProvider>
        </ReduxProvider>
      </body>
    </html>
  );
}
