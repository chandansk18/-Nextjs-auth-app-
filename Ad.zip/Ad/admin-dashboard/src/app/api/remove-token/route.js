// app/api/remove-token/route.js
import { cookies } from 'next/headers';

export async function POST() {
  cookies().set('token', '', {
    httpOnly: true,
    path: '/',
    expires: new Date(0),
  });

  return new Response(JSON.stringify({ success: true }), { status: 200 });
}
