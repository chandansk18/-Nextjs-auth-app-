import {  useCallback } from "react";
import { useApiRequest } from "@/lib/apiService";
import { useTokenHandler } from "./useTokenHandler";

export const useFetchApi = () => {
  const { handleTokenRefresh } = useTokenHandler();
  const { tokenGetRequest } = useApiRequest();


  const fetchData = useCallback(
    async (url) => {

      try {
        const response = await tokenGetRequest(url);
        return response;
      } catch (error) {
        if (
          error.response?.status === 401 &&
          error.response?.data?.message === "Invalid token"
        ) {
          console.log("Invalid token:", error.message);
          try {
            const retryResponse = await handleTokenRefresh();
            if (retryResponse?.status) {
              const refreshedResponse = await tokenGetRequest(url);
              return refreshedResponse;
            } else {
              throw new Error("Token refresh failed");
            }
          } catch (refreshError) {
            console.error("Token refresh failed:", refreshError);
            throw refreshError;
          }
        } else {
          // toast.error(error?.response?.data?.message || "Error fetching data");
          console.error("Error fetching data:", error);
          throw error;
        }
      }
    },
    [handleTokenRefresh]
  );

  return { fetchData };
};
