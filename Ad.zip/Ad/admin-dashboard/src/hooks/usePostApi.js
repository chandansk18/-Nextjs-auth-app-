import { useApiRequest } from "@/lib/apiService";
import { useCallback } from "react";
import { toast } from "react-hot-toast";
import { useTokenHandler } from "./useTokenHandler";

export const usePostApi = () => {
  const { tokenPostRequest, tokenPostRequestMultipart } = useApiRequest();
  const { handleTokenRefresh } = useTokenHandler();
  // Utility for centralized error handling
  const handleApiError = (error) => {
    toast.error(error?.response?.data?.message || "Error processing request");
    console.log("Error processing request:", error);
    throw error;
  };

  const postData = useCallback(
    async ({url, payload , multipart}) => {
      try {
        // Make the API call

        const response = await (multipart ? tokenPostRequestMultipart : tokenPostRequest)({
          url,
          cred: payload,
        });

        if (response.data?.status === "success") {
          return response;
        } 
      } catch (error) {
        if (
          error.response?.status === 401 &&
          error.response?.data?.message === "Invalid token"
        ) {
          console.error("Invalid token:", error.message);
          try {
            const refreshResponse = await handleTokenRefresh(); // Token refresh only here
            if (refreshResponse.status === "success") {
              // After token refresh, retry the original request
              const retryResponse = await tokenPostRequest({
                url,
                cred: payload,
              });
              if (retryResponse.data?.status === "success") {
                return retryResponse;
              } else {
                throw new Error(
                  retryResponse.data?.message || "Error processing request"
                );
              }
            } else {
              throw new Error("Failed to refresh token");
            }
          } catch (refreshError) {
            console.error("Token refresh failed:", refreshError);
            throw refreshError;
          }
        } else {
          handleApiError(error);
        }
      }
    },
    [handleTokenRefresh, tokenPostRequest] // Dependencies
  );

  return { postData };
};
