import { useCallback } from "react";

const useCurrencyFormater = () => {
  const convertInRupee = useCallback((number) => {
    return number?.toLocaleString("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }, []);

  return { convertInRupee };
};

export default useCurrencyFormater;


