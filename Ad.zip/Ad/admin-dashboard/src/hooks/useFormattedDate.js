import { useCallback } from "react";
import dayjs from "dayjs";

const useFormattedDate = () => {
  const formattedDate = useCallback((dateString) => {
    if (!dateString) return "";
    return dayjs(dateString).format("DD/MM/YYYY");
  }, []);

  const formattedDateTime = useCallback((dateString) => {
    if (!dateString) return "";
    return dayjs(dateString).format("DD/MM/YYYY HH:mm:ss");
  }, []);

  return { formattedDate, formattedDateTime };
};

export default useFormattedDate;

