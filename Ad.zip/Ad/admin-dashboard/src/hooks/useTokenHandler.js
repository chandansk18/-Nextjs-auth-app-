import { useDispatch } from "react-redux";
import toast from "react-hot-toast";
import { useCallback } from "react";
import { refreshToken } from "@/redux/slices/authSlice";

export const useTokenHandler = () => {
  const dispatch = useDispatch();

  const handleTokenRefresh = useCallback(async () => {
    try {
      await dispatch(refreshToken()).unwrap();
      return { status: "success" };
    } catch (refreshError) {
      console.error("Token refresh failed:", refreshError);
      toast.custom("Not authorized");
      dispatch(logout());
      throw refreshError;
    }
  }, [dispatch]);

  return { handleTokenRefresh };
};
