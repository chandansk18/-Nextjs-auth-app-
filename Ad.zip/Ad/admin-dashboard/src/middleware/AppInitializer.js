import { useDispatch } from "react-redux";
import { useEffect } from "react";
import toast from "react-hot-toast";
import { logout, refreshToken, verifyToken } from "@/redux/slices/authSlice";
import Cookies from "js-cookie";

function AppInitializer({ children }) {
  const dispatch = useDispatch();

  useEffect(() => {
    const initializeApp = async () => {
      const webToken = Cookies.get(process.env.NEXT_PUBLIC_WEB_TOKEN);

      if (!webToken) {
        dispatch(logout());
        // toast.error("Session expired. Please login again.");
        return;
      }

      try {
        await dispatch(verifyToken()).unwrap();
      } catch (error) {
        console.error("Verify token failed:", error?.message);

        try {
          await dispatch(refreshToken()).unwrap();
          await dispatch(verifyToken()).unwrap();
        } catch (refreshError) {
          console.error("Token refresh failed:", refreshError);
          toast.error("Session expired. Please login again.");
          dispatch(logout());
        }
      }
    };

    initializeApp();
  }, [dispatch]);

  return <>{children}</>;
}

export default AppInitializer;
